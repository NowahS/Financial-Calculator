#include <stdio.h>
#include <math.h>

double add(double a, double b) {
    return a + b;
}

double subtract(double a, double b) {
    return a - b;
}

double multiply(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    return a / b;
}

double ROI(double a, double b) {
  double netProfit = b - a;
  return(netProfit/a)*100.0;
}

double WACC(double ke, double kd, double we, double wd, double t) {
    int after_tax = ke * (1 - t);
    return (ke * we) + (after_tax * wd);
}

double LP(double l, double r, double n) {
    r /= 12;
    return (l * r * pow((1 + r), n)) / (pow((1 + r), n) - 1);
}

double currency_conversion(double a, double e) {
    return a * e;
}

int main(void) {
    char choice;
    do {
        printf("Welcome to your financial calculator!\n");
        printf("What calculation are you trying to accomplish today?\n");
        printf("A: Arithmetic (+, -, *, /)\n");
        printf("R: ROI (return on investment)\n");
        printf("W: WACC (weighted average cost of capital)\n");
        printf("L: Loan repayment (LP)\n");
        printf("C: Currency conversion\n");
        printf("Enter your choice: ");

        scanf(" %c", &choice);

        switch (choice) {
            case 'A':
            case 'a':
                printf("You have chosen Arithmetic!\n");
                printf("Enter the first number: ");
                double num1;
                scanf("%lf", &num1);
                printf("Enter the second number: ");
                double num2;
                scanf("%lf", &num2);
                printf("Enter the operation (+, -, *, /): ");
                char op;
                scanf(" %c", &op);

                if (op == '+') {
                    printf("Result: %lf\n", add(num1, num2));
                } else if (op == '-') {
                    printf("Result: %lf\n", subtract(num1, num2));
                } else if (op == '*') {
                    printf("Result: %lf\n", multiply(num1, num2));
                } else if (op == '/') {
                    printf("Result: %lf\n", divide(num1, num2));
                } else {
                    printf("Invalid operation\n");
                }
                break;
            case 'R':
            case 'r':
              printf("You have chosen Return On Investment!\n");
              printf("Enter the cost of the investment: ");
              double initial_invest;
              scanf("%lf", &initial_invest);
              printf("Enter the final value: ");
              double finalValue;
              scanf("%lf", &finalValue);

              double roiResutls = ROI(initial_invest, finalValue);
              printf("ROI results: %lf%%\n", roiResutls);
                break;
            case 'W':
            case 'w':
              printf("You have chosen Weighted Average Cost of Capital!\n");
              printf("Enter the cost of equity: ");
              double ke = scanf("%lf", &ke);
              printf("Enter the cost of debt: ");
              double kd;
              scanf("%lf", &kd);
              printf("Enter the weight of equity: ");
              double we;
              scanf("%lf", &we);
              printf("Enter the weight of debt: ");
              double wd;
              scanf("%lf", &wd);
              printf("Enter the tax rate: ");
              double t;
              scanf("%lf", &t);
              double waccResult = WACC(ke, kd, we, wd, t);
              printf("WACC results: %lf\n", waccResult);
                break;
            case 'L':
            case 'l':
              printf("You have chosen Loan Repayment!\n");
              printf("Enter the loan amount: ");
              double loanAmount;
              scanf("%lf", &loanAmount);
              printf("Enter the annual interest rate: ");
              double annualInterestRate;
              scanf("%lf", &annualInterestRate);
              printf("Enter the loan term number of years: ");
              double loanTerm;
              scanf("%lf", &loanTerm);
              //assumes it is paid monthly
              double LPResults = LP(loanAmount, annualInterestRate, loanTerm);
              printf("Loan repayment results: %lf\n", LPResults);
                break;
            case 'C':
            case 'c':
              printf("You have chosen Currency Conversion!\n");
              printf("Enter your source currency amount: ");
              double sourceCurrencyAmount;
              scanf("%lf", &sourceCurrencyAmount);
              printf("Enter the exchange rate for what you are converting to: ");
              double exchangeRate;
              scanf("%lf", &exchangeRate);
              double currency_convertResult = currency_conversion(sourceCurrencyAmount, exchangeRate);
              printf("Currency conversion results: %lf\n", currency_convertResult);
                break;
            default:
                printf("Invalid choice\n");
        }

        // Ask the user if they want to make more calculations
        printf("Do you want to make another calculation? (Y/N): ");
        scanf(" %c", &choice);

    } while (choice == 'Y' || choice == 'y');

    printf("Goodbye!\n");

    return 0;
}
